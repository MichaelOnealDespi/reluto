package com.example.project.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.project.R;

public class ContactUsActivity extends AppCompatActivity {

    private static final int EMAIL_REQUEST_CODE = 1; // Request code for email intent
    private EditText nameInput;
    private EditText emailInput;
    private EditText messageInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        // Find the back button and send button using their IDs
        ImageView backButton = findViewById(R.id.backbtn);


        // Set an OnClickListener for the back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Close ContactUsActivity and return to the previous activity
            }
        });


   
    }
}
