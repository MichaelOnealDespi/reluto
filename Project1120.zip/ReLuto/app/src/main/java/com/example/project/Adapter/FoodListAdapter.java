package com.example.project.Adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.example.project.Activity.DetailActivity;
import com.example.project.Domain.Foods;
import com.example.project.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class FoodListAdapter extends RecyclerView.Adapter<FoodListAdapter.ViewHolder> {
    ArrayList<Foods> items;
    Context context;
    FirebaseFirestore firestore;
    DatabaseReference userLikesReference;

    public FoodListAdapter(ArrayList<Foods> items) {
        this.items = items;
        firestore = FirebaseFirestore.getInstance();
        userLikesReference = FirebaseDatabase.getInstance().getReference("UserLikes");
    }

    @NonNull
    @Override
    public FoodListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View inflate = LayoutInflater.from(context).inflate(R.layout.viewholder_list_food, parent, false);
        return new ViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodListAdapter.ViewHolder holder, int position) {
        Foods food = items.get(position);
        holder.titleTxt.setText(food.getTitle());
        holder.ingredientsTxt.setText(food.getIngredients());

        // Set the timer
        String timer = food.getTimerId();
        holder.timerTxt.setText(timer != null ? timer : "N/A");

        // Load the image
        Glide.with(context)
                .load(food.getImagePath())
                .transform(new CenterCrop(), new RoundedCorners(30))
                .into(holder.pic);

        // Fetch and display the uploader's full name
        displayUserFullName(food.getUserId(), holder.whoTxt);

        // Load user likes and set rating
        loadUserLikes(food.getRecipeId(), holder.countlike, holder.ratingBar2);

        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("object", food);
            context.startActivity(intent);
        });
    }

    private void loadUserLikes(String recipeId, TextView countlike, RatingBar ratingBar2) {
        userLikesReference.child(recipeId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int totalLikes = 0;
                int userCount = 0;

                // Iterate over all children in the snapshot
                for (DataSnapshot ratingSnapshot : snapshot.getChildren()) {
                    // Check if the value is actually a rating, and not a timestamp or other data.
                    if (ratingSnapshot.child("rating").exists()) {
                        Integer rating = ratingSnapshot.child("rating").getValue(Integer.class);
                        if (rating != null) {
                            totalLikes += rating;  // Sum up the ratings
                            userCount++;  // Increment user count
                        }
                    }
                }

                // Calculate average rating
                float averageLikes = userCount > 0 ? (float) totalLikes / userCount : 0;
                String formattedLikes = String.format("%.2f", averageLikes);
                countlike.setText(formattedLikes);  // Display the average rating

                // Set the RatingBar to the calculated average rating
                ratingBar2.setRating(averageLikes);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle any errors that occur during the Firebase read operation
                Log.e("Firebase", "Error loading user likes: " + error.getMessage());
            }
        });
    }



    private void displayUserFullName(String userId, TextView nameTextView) {
        firestore.collection("foodtech").document(userId).get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            String fullName = document.getString("fullName");
                            String lastName = document.getString("lastName");
                            if (fullName != null && lastName != null) {
                                nameTextView.setText("By: " + fullName + " " + lastName);
                            } else {
                                nameTextView.setText("By: Unknown");
                            }
                        } else {
                            nameTextView.setText("By: Unknown");
                        }
                    } else {
                        nameTextView.setText("By: Unknown");
                    }
                });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleTxt, ingredientsTxt, timerTxt, whoTxt, countlike; // Added whoTxt
        ImageView pic;
        RatingBar ratingBar2;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTxt = itemView.findViewById(R.id.titleTxt);
            ingredientsTxt = itemView.findViewById(R.id.ingredientsTxt);
            timerTxt = itemView.findViewById(R.id.asdadasda); // Make sure this ID is correct
            whoTxt = itemView.findViewById(R.id.whoTxt); // Initialize whoTxt
            pic = itemView.findViewById(R.id.imgs);
            ratingBar2 = itemView.findViewById(R.id.ratingBar2); // Ensure this ID matches your layout
            countlike = itemView.findViewById(R.id.countlike);
        }
    }
}
