package com.example.project.Activity;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.graphics.Typeface;



import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.project.Domain.Category;
import com.example.project.Domain.Foods;
import com.example.project.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EditRecipeActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private Uri imageUri;

    private FirebaseAuth auth;
    private FirebaseDatabase database;
    private StorageReference storageReference;
    private String originalTitle;
    private String originalDescription;
    private String originalIngredients;
    private String originalProcedure;
    private TextView CategorySelectedText;
    private EditText titleEdt, descriptionEdt, ingredientsEdt, procedureEdt, commentsEdt, equipmentEdt, timerEdt, minsEdt, secsEdt;
    private Spinner categorySpinner;
    private ImageView imageView;
    private Button saveRecipeBtn, deleteRecipeBtn, backBtn, uploadImageBtn;

    private String recipeId;
    private List<Map<String, String>> selectedCategoriesList = new ArrayList<>();
    private EditText currentExpandedEditText = null;
    private final int EXPANDED_HEIGHT = 300; // Adjust as needed
    private final int COLLAPSED_HEIGHT = 70; // Original height

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_recipe);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference("images");

        titleEdt = findViewById(R.id.titleEdt);
        timerEdt = findViewById(R.id.timerEdt); // Added timerEdt
        minsEdt = findViewById(R.id.minsEdt);
        secsEdt = findViewById(R.id.secsEdt);
        descriptionEdt = findViewById(R.id.descriptionEdt);
        ingredientsEdt = findViewById(R.id.ingredientsEdt);
        procedureEdt = findViewById(R.id.procedureEdt);
        commentsEdt = findViewById(R.id.commentsEdt);
        equipmentEdt = findViewById(R.id.equipmentEdt);
        categorySpinner = findViewById(R.id.categorySpinner);
        imageView = findViewById(R.id.imageView);
        deleteRecipeBtn = findViewById(R.id.deleteRecipeBtn);
        backBtn = findViewById(R.id.backBtn);
        saveRecipeBtn = findViewById(R.id.saveRecipeBtn);
        uploadImageBtn = findViewById(R.id.uploadImageBtn);
        CategorySelectedText = findViewById(R.id.CategorySelected);

        setCapitalizationWatcher(titleEdt, true);        // Only capitalization, allow spaces
        setCapitalizationWatcher(descriptionEdt, true);  // Only capitalization, allow spaces
        setCapitalizationWatcher(ingredientsEdt, false); // Bullet points + capitalization
        setCapitalizationWatcher(procedureEdt, false);   // Bullet points + capitalization
        setCapitalizationWatcher(equipmentEdt, false);  // Bullet points + capitalization
        setCapitalizationWatcher(commentsEdt, false);    // Bullet points + capitalization

        populateCategorySpinner();
        selectedCategoriesList = new ArrayList<>();
        // Retrieve the recipe ID from the intent
        Intent intent = getIntent();
        recipeId = intent.getStringExtra("recipeId");

        if (recipeId != null) {
            // Load the recipe if a valid recipe ID is provided
            loadRecipe(recipeId);
        }
        saveRecipeBtn.setOnClickListener(v -> updateRecipe());
        deleteRecipeBtn.setOnClickListener(view -> showDeleteConfirmationDialog());

        backBtn.setOnClickListener(view -> {
            Intent backIntent = new Intent(EditRecipeActivity.this, FoodtechProfileActivity.class);
            startActivity(backIntent);
            finish(); // This will finish EditRecipeActivity
        });

        imageView.setOnClickListener(v -> openFileChooser());
        uploadImageBtn.setOnClickListener(v -> openFileChooser());

        // Set up click listeners for EditText fields

    }

    private void setCapitalizationWatcher(EditText editText, boolean isTitleOrDescription) {
        editText.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                editText.removeTextChangedListener(this); // Temporarily remove the listener to prevent recursion

                String text = s.toString();
                String[] lines = text.split("\n");
                StringBuilder formattedText = new StringBuilder();
                int cursorPosition = editText.getSelectionStart(); // Get the current cursor position

                for (String line : lines) {
                    if (line.isEmpty()) {
                        formattedText.append("\n");
                        continue;
                    }

                    boolean isBulletLine = line.startsWith("•");
                    String capitalizedLine;

                    if (isTitleOrDescription) {
                        capitalizedLine = Character.toUpperCase(line.charAt(0)) + line.substring(1);
                    } else {
                        if (!isBulletLine) {
                            capitalizedLine = "• " + Character.toUpperCase(line.charAt(0)) + line.substring(1);
                        } else {
                            if (line.length() > 2 && Character.isLowerCase(line.charAt(2))) {
                                capitalizedLine = "• " + Character.toUpperCase(line.charAt(2)) + line.substring(3);
                            } else {
                                capitalizedLine = line;
                            }
                        }
                    }
                    formattedText.append(capitalizedLine).append("\n");
                }

                // Remove the last newline if it exists
                if (formattedText.length() > 0 && formattedText.charAt(formattedText.length() - 1) == '\n') {
                    formattedText.setLength(formattedText.length() - 1);
                }

                // Update the EditText if text has changed
                if (!formattedText.toString().equals(text)) {
                    editText.setText(formattedText.toString());

                    // Place cursor after bullet in the same line if possible
                    int bulletPosition = formattedText.indexOf("•", cursorPosition > 0 ? cursorPosition - 3 : 0);
                    if (bulletPosition != -1) {
                        int positionAfterBullet = bulletPosition + 3; // Move cursor after the bullet and space
                        editText.setSelection(Math.min(positionAfterBullet, formattedText.length()));
                    } else {
                        editText.setSelection(Math.min(cursorPosition, formattedText.length()));
                    }
                } else {
                    editText.setSelection(Math.min(cursorPosition, formattedText.length()));
                }

                // Add bullet point if last character is a newline
                if (s.length() > 0 && s.charAt(s.length() - 1) == '\n') {
                    editText.setText(s.toString() + "• "); // Add bullet and space for the new line
                    editText.setSelection(editText.getText().length()); // Position cursor after the bullet
                }

                // Remove any empty bullet or empty line at the end
                String[] updatedLines = editText.getText().toString().split("\n");
                if (updatedLines.length > 0) {
                    String lastLine = updatedLines[updatedLines.length - 1].trim();
                    if (lastLine.equals("•") || lastLine.isEmpty()) {
                        StringBuilder newText = new StringBuilder();
                        for (int i = 0; i < updatedLines.length - 1; i++) {
                            newText.append(updatedLines[i]).append("\n");
                        }
                        editText.setText(newText.toString());
                        editText.setSelection(editText.getText().length()); // Move the cursor to the end
                    }
                }

                editText.addTextChangedListener(this); // Re-add the listener
            }
        });
    }




    private void populateCategorySpinner() {
        String[] categories = {"Breakfast", "Lunch", "Dinner", "Dessert", "Appetizer", "Snacks", "Side Dish", "More"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Select Category"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        categorySpinner.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                showMultiSelectDialog(categories);
                return true;
            }
            return false;
        });
    }

    private void showMultiSelectDialog(String[] categories) {
        boolean[] checkedItems = new boolean[categories.length];

        // Initialize checkedItems based on selectedCategoriesList
        for (int i = 0; i < categories.length; i++) {
            for (Map<String, String> category : selectedCategoriesList) {
                if (category.get("CategoryName").equals(categories[i])) {
                    checkedItems[i] = true;
                    break;
                }
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Categories")
                .setMultiChoiceItems(categories, checkedItems, (dialog, which, isChecked) -> {
                    Map<String, String> category = new HashMap<>();
                    category.put("CategoryId", String.valueOf(which + 1)); // Adjust as needed
                    category.put("CategoryName", categories[which]);

                    if (isChecked) {
                        // Only add if not already present
                        if (!selectedCategoriesList.stream()
                                .anyMatch(cat -> cat.get("CategoryName").equals(category.get("CategoryName")))) {
                            selectedCategoriesList.add(category);
                        }
                    } else {
                        // Remove the category based on CategoryId
                        selectedCategoriesList.removeIf(cat -> cat.get("CategoryId").equals(String.valueOf(which + 1)));
                    }
                })
                .setPositiveButton("OK", (dialog, which) -> updateSelectedCategoriesText())
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }


    private void updateSelectedCategoriesText() {
        StringBuilder selectedCategories = new StringBuilder("Selected Category:\n");
        for (Map<String, String> category : selectedCategoriesList) {
            selectedCategories.append("• ").append(category.get("CategoryName")).append("\n");
        }

        // Remove the last newline if necessary
        if (selectedCategories.length() > 0) {
            selectedCategories.setLength(selectedCategories.length() - 1); // Adjust this if it has issues
        }

        // Update a TextView or other UI element to show selected categories
        CategorySelectedText.setText(selectedCategories.toString().trim()); // Set text in TextView
    }


    private void loadRecipe(String recipeId) {
        DatabaseReference recipeRef = database.getReference("Foods").child(recipeId);
        recipeRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Foods food = dataSnapshot.getValue(Foods.class);
                if (food != null) {
                    titleEdt.setText(food.getTitle());
                    originalTitle = food.getTitle(); // Store original title

                    String timerString = food.getTimerId();
                    Log.d("LoadRecipe", "Timer String: " + timerString); // Debug log

                    String[] timeParts = timerString != null ? timerString.split(" ") : new String[0];
                    String hours = "", minutes = "", seconds = ""; // Initialize with default values

                    // Extract hours, minutes, and seconds
                    for (int i = 0; i < timeParts.length; i++) {
                        if (timeParts[i].equalsIgnoreCase("Hour") || timeParts[i].equalsIgnoreCase("Hours")) {
                            if (i > 0) {
                                hours = timeParts[i - 1]; // Get the value before "Hour(s)"
                            }
                        } else if (timeParts[i].equalsIgnoreCase("Minute") || timeParts[i].equalsIgnoreCase("Minutes")) {
                            if (i > 0) {
                                minutes = timeParts[i - 1]; // Get the value before "Minute(s)"
                            }
                        } else if (timeParts[i].equalsIgnoreCase("Second") || timeParts[i].equalsIgnoreCase("Seconds")) {
                            if (i > 0) {
                                seconds = timeParts[i - 1]; // Get the value before "Second(s)"
                            }
                        }
                    }

                    // Set values to EditTexts
                    timerEdt.setText(hours);   // Set hours, leave blank if no value
                    minsEdt.setText(minutes);   // Set minutes, leave blank if no value
                    secsEdt.setText(seconds);   // Set seconds, leave blank if no value

                    descriptionEdt.setText(food.getDescription() != null ? food.getDescription() : "");
                    originalDescription = food.getDescription(); // Store original description
                    ingredientsEdt.setText(food.getIngredients() != null ? food.getIngredients() : "");
                    originalIngredients = food.getIngredients(); // Store original ingredients
                    procedureEdt.setText(food.getProcedure() != null ? food.getProcedure() : "");
                    originalProcedure = food.getProcedure(); // Store original procedure
                    commentsEdt.setText(food.getComments() != null ? food.getComments() : "");
                    equipmentEdt.setText(food.getEquipment() != null ? food.getEquipment() : "");

                    // Load selected categories for the recipe
                    selectedCategoriesList.clear(); // Clear previous selections
                    String categoryNamesString = food.getCategoryName(); // Get the full category string
                    if (categoryNamesString != null && !categoryNamesString.isEmpty()) {
                        String[] categoryNames = categoryNamesString.split(",\\s*"); // Split by comma and optional whitespace
                        for (String categoryName : categoryNames) {
                            categoryName = categoryName.trim(); // Trim any leading or trailing spaces
                            if (!categoryName.isEmpty()) { // Ensure it’s not empty after trimming
                                Map<String, String> category = new HashMap<>();
                                category.put("CategoryId", String.valueOf(getCategoryId(categoryName))); // Implement getCategoryId method to map names to IDs
                                category.put("CategoryName", categoryName);
                                selectedCategoriesList.add(category);
                            }
                        }
                    }

                    // Call the method to update the selected categories text
                    updateSelectedCategoriesText();

                    // Load image if available
                    if (food.getImagePath() != null) {
                        Glide.with(EditRecipeActivity.this).load(food.getImagePath()).into(imageView);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle error
                // Toast.makeText(EditRecipeActivity.this, "Error loading recipe: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }



    private void updateRecipe() {
        // Retrieve text directly from EditText fields
        String title = titleEdt.getText().toString().trim();
        String hours = timerEdt.getText().toString().trim();
        String minutes = minsEdt.getText().toString().trim();
        String seconds = secsEdt.getText().toString().trim();

        String timer = String.format("%s%s%s",
                hours.isEmpty() || hours.equals("0") ? "" : hours + (Integer.parseInt(hours) > 1 ? " Hours " : " Hour "),
                minutes.isEmpty() || minutes.equals("0") ? "" : minutes + (Integer.parseInt(minutes) > 1 ? " Minutes " : " Minute "),
                seconds.isEmpty() || seconds.equals("0") ? "" : seconds + (Integer.parseInt(seconds) > 1 ? " Seconds" : " Second"));

        String description = descriptionEdt.getText().toString().trim();
        String ingredients = ingredientsEdt.getText().toString().trim();
        String procedure = procedureEdt.getText().toString().trim();
        String comments = commentsEdt.getText().toString().trim();
        String equipment = equipmentEdt.getText().toString().trim();

        // Check if any fields are empty
        if (title.isEmpty() || timer.isEmpty() || description.isEmpty() || ingredients.isEmpty() ||
                procedure.isEmpty() || comments.isEmpty() || equipment.isEmpty()) {
            Toast.makeText(EditRecipeActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the new values are the same as the original
        boolean titleChanged = !title.equalsIgnoreCase(originalTitle);
        boolean descriptionChanged = !description.equalsIgnoreCase(originalDescription);
        boolean ingredientsChanged = !ingredients.equalsIgnoreCase(originalIngredients);
        boolean procedureChanged = !procedure.equalsIgnoreCase(originalProcedure);

        // If no changes, simply show confirmation dialog
        if (!titleChanged && !descriptionChanged && !ingredientsChanged && !procedureChanged) {
            showConfirmationDialog(title, description, ingredients, procedure, equipment, comments, timer);
            return;
        }

        // Query to check if the recipe with the same title exists
        Query recipeRef = database.getReference("Foods");
        recipeRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                boolean recipeExists = false;
                StringBuilder duplicatedFields = new StringBuilder();

                // Iterate through all the recipes and check for duplicates
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    // Skip the current recipe being edited
                    if (snapshot.getKey().equals(recipeId)) {
                        continue;
                    }

                    // Check for duplicates only in changed fields
                    if (descriptionChanged && snapshot.child("Description").getValue(String.class).equalsIgnoreCase(description)) {
                        recipeExists = true;
                        duplicatedFields.append("Description: ").append(description).append("\n");
                    }
                    if (titleChanged && snapshot.child("Title").getValue(String.class).equalsIgnoreCase(title)) {
                        recipeExists = true;
                        duplicatedFields.append("Title: ").append(title).append("\n");
                    }
                    if (ingredientsChanged && snapshot.child("Ingredients").getValue(String.class).equalsIgnoreCase(ingredients)) {
                        recipeExists = true;
                        duplicatedFields.append("Ingredients: ").append(ingredients).append("\n");
                    }
                    if (procedureChanged && snapshot.child("Procedure").getValue(String.class).equalsIgnoreCase(procedure)) {
                        recipeExists = true;
                        duplicatedFields.append("Procedure: ").append(procedure).append("\n");
                    }
                }

                // Remove the last newline if there are duplicated fields
                if (duplicatedFields.length() > 0) {
                    duplicatedFields.setLength(duplicatedFields.length() - 1);
                }

                // Show the existing recipe dialog if duplicates found
                if (recipeExists) {
                    showRecipeExistsDialog(duplicatedFields.toString(), title, timer, description, ingredients, procedure, commentsEdt.getText().toString().trim(), equipmentEdt.getText().toString().trim());
                } else {
                    showConfirmationDialog(title, description, ingredients, procedure, equipmentEdt.getText().toString().trim(), commentsEdt.getText().toString().trim(), timer);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(EditRecipeActivity.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }





    private boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }



    private void showRecipeExistsDialog(String duplicatedFields, String title, String timer, String description, String ingredients, String procedure, String comments, String equipment) {
        // Construct the dialog message with formatted duplicated fields
        String finalMessage = "The following fields already exist:\n" + duplicatedFields + "\nDo you wish to proceed or change your recipe details?";

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Recipe Already Exists");
        builder.setMessage(finalMessage);
        builder.setPositiveButton("Save Recipe", (dialog, which) -> {
            // Proceed to update the recipe only if Save Recipe is clicked
            proceedToUpdateRecipe(title, timer, description, ingredients, procedure, comments, equipment);
        });
        builder.setNegativeButton("Change Recipe Details", (dialog, which) -> {
            // Cancel the update and dismiss the dialog
            dialog.dismiss();
        });
        builder.create().show();
    }

    private void showConfirmationDialog(String title, String description, String ingredients, String procedure, String equipment, String comments, String timer) {
        // Build and display the confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Update Recipe");
        builder.setMessage("Do you want to update this recipe?");
        builder.setPositiveButton("Yes", (dialog, which) -> {
            // Proceed to update the recipe
            proceedToUpdateRecipe(title, timer, description, ingredients, procedure, comments, equipment);
        });
        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }


    private void proceedToUpdateRecipe(String title, String timer, String description, String ingredients, String procedure, String comments, String equipment) {
        if (recipeId != null) {
            DatabaseReference ref = database.getReference("Foods").child(recipeId);

            // Concatenate category names
            StringBuilder categoryNames = new StringBuilder();
            int categoryId = 0; // Initialize to 0 in case there are no categories

            for (Map<String, String> category : selectedCategoriesList) {
                if (categoryNames.length() > 0) {
                    categoryNames.append(", ");
                }
                categoryNames.append(category.get("CategoryName"));

                // Store the first selected category ID
                if (categoryId == 0) {
                    categoryId = Integer.parseInt(category.get("CategoryId"));
                }
            }

            Map<String, Object> foodMap = new HashMap<>();
            foodMap.put("Title", title);
            foodMap.put("TimerId", timer);
            foodMap.put("Description", description);
            foodMap.put("Ingredients", ingredients);
            foodMap.put("Procedure", procedure);
            foodMap.put("Comments", comments);
            foodMap.put("Equipment", equipment);
            foodMap.put("CategoryId", categoryId);
            foodMap.put("CategoryName", categoryNames.toString()); // Store concatenated category names
            foodMap.put("Star", 4.5);
            foodMap.put("LocationId", 1);
            foodMap.put("Price", 10.99);
            foodMap.put("PriceId", 1);
            foodMap.put("TimeId", 1);
            foodMap.put("TypeId", 1);
            foodMap.put("Count", 1);
            foodMap.put("UserId", auth.getCurrentUser().getUid());

            ref.updateChildren(foodMap).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(EditRecipeActivity.this, "Recipe updated successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(EditRecipeActivity.this, "Failed to update recipe", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }



    private void deleteRecipe() {
        if (recipeId != null) {
            DatabaseReference ref = database.getReference("Foods").child(recipeId);
            ref.removeValue().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(EditRecipeActivity.this, "Recipe deleted successfully", Toast.LENGTH_SHORT).show();
                    // Navigate back to the profile activity
                    Intent backIntent = new Intent(EditRecipeActivity.this, FoodtechProfileActivity.class);
                    startActivity(backIntent);
                    finish(); // This will finish EditRecipeActivity
                } else {
                    Toast.makeText(EditRecipeActivity.this, "Failed to delete recipe", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                imageView.setImageBitmap(bitmap);
                uploadImage();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void uploadImage() {
        if (imageUri != null) {
            StorageReference fileReference = storageReference.child(System.currentTimeMillis() + ".jpg");
            UploadTask uploadTask = fileReference.putFile(imageUri);
            uploadTask.addOnSuccessListener(taskSnapshot -> fileReference.getDownloadUrl().addOnSuccessListener(uri -> {
                String imagePath = uri.toString();
                DatabaseReference recipeRef = database.getReference("Foods").child(recipeId);
                recipeRef.child("ImagePath").setValue(imagePath);
                Toast.makeText(EditRecipeActivity.this, "Image uploaded", Toast.LENGTH_SHORT).show();
            })).addOnFailureListener(e -> Toast.makeText(EditRecipeActivity.this, "Image upload failed", Toast.LENGTH_SHORT).show());
        }
    }

    private int getCategoryId(String categoryName) {
        switch (categoryName) {
            case "Breakfast":
                return 1;
            case "Lunch":
                return 2;
            case "Dinner":
                return 3;
            case "Dessert":
                return 4;
            case "Appetizer":
                return 5;
            case "Snacks":
                return 6;
            case "Side Dish":
                return 7;
            case "More":
                return 8;
            default:
                return 0;
        }
    }

    private String getCategoryName(int categoryId) {
        switch (categoryId) {
            case 1:
                return "Breakfast";
            case 2:
                return "Lunch";
            case 3:
                return "Dinner";
            case 4:
                return "Dessert";
            case 5:
                return "Appetizer";
            case 6:
                return "Snacks";
            case 7:
                return "Side Dish";
            case 8:
                return "More";
            default:
                return "";
        }
    }

    private String capitalizeFirstLetter(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return text.substring(0, 1).toUpperCase() + text.substring(1).toLowerCase();
    }


    private void showDeleteConfirmationDialog() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Delete Recipe")
                .setMessage("Do you wish to delete your recipe?")
                .setPositiveButton("Yes", (dialog, which) -> deleteRecipe())
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }
}
