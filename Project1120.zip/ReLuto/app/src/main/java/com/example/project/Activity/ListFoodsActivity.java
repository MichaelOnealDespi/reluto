package com.example.project.Activity;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.Adapter.FoodListAdapter;
import com.example.project.Domain.Foods;
import com.example.project.R;
import com.example.project.databinding.ActivityListFoodsBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ListFoodsActivity extends BaseActivity {
    ActivityListFoodsBinding binding;
    private RecyclerView.Adapter adapterListFood;
    private int categoryId;
    private String searchText;
    private boolean isSearch;
    private  String categoryName;
    private List<String> selectedIngredients; // For ingredient filtering

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityListFoodsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getIntentExtra();
        initList();
        setVariable();
    }

    private void getIntentExtra() {
        categoryId = getIntent().getIntExtra("CategoryId", 0);
        categoryName = getIntent().getStringExtra("CategoryName"); // Assign to the class-level variable
        searchText = getIntent().getStringExtra("text");
        isSearch = getIntent().getBooleanExtra("isSearch", false);
        selectedIngredients = getIntent().getStringArrayListExtra("Ingredients");

        binding.titleTxt.setText("Food List");
        binding.backBtn.setOnClickListener(view -> finish());
    }



    private void initList() {
        DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("Foods");
        binding.progressBar.setVisibility(View.VISIBLE);

        ArrayList<String> filteredFoodIds = getIntent().getStringArrayListExtra("filteredFoodIds");
        Set<String> uniqueFoodKeys = new HashSet<>();
        ArrayList<Foods> list = new ArrayList<>();

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        Foods food = issue.getValue(Foods.class);
                        String foodKey = issue.getKey();

                        if (food != null) {
                            boolean isInFilteredIds = filteredFoodIds == null || filteredFoodIds.contains(foodKey);
                            boolean isUnique = !uniqueFoodKeys.contains(foodKey);

                            if (isInFilteredIds && isUnique) {
                                uniqueFoodKeys.add(foodKey);

                                // Check if food matches categoryId or categoryName
                                boolean matchesCategory = matchesMultipleCategories(food);
                                boolean matchesIngredients = matchesIngredients(food);

                                boolean matchesSearch = true;
                                if (isSearch && searchText != null && !searchText.isEmpty()) {
                                    String[] searchTerms = searchText.split("\\s+");
                                    String title = food.getTitle();
                                    String ingredients = food.getIngredients();
                                    matchesSearch = (title != null && containsAllTerms(title, searchTerms)) ||
                                            (ingredients != null && containsAllTerms(ingredients, searchTerms));
                                }

                                // Add food to list if any category condition matches
                                if (matchesCategory && matchesIngredients && matchesSearch) {
                                    list.add(food);
                                }
                            }
                        }
                    }
                    updateRecyclerView(list);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                binding.progressBar.setVisibility(View.GONE);
            }
        });
    }

    private boolean matchesMultipleCategories(Foods food) {
        if (categoryId != 0 || (categoryName != null && !categoryName.isEmpty())) {
            // Assuming food.getCategories() returns a comma-separated string of categories
            List<String> foodCategories = new ArrayList<>();
            if (food.getCategoryName() != null) {
                String[] categoriesArray = food.getCategoryName().split(",\\s*");
                foodCategories.addAll(Arrays.asList(categoriesArray));
            }

            // Check if the food's categories contain the selected categoryId or categoryName
            boolean matchesCategoryId = categoryId != 0 && food.getCategoryId() == categoryId;
            boolean matchesCategoryName = foodCategories.contains(categoryName);

            return matchesCategoryId || matchesCategoryName;
        }
        return true; // No category filtering applied
    }



    private boolean containsAllTerms(String text, String[] searchTerms) {
        for (String term : searchTerms) {
            if (!text.toLowerCase().contains(term.trim().toLowerCase())) {
                return false;
            }
        }
        return true;
    }

    private boolean matchesIngredients(Foods food) {
        if (selectedIngredients == null || selectedIngredients.isEmpty()) {
            return true;
        }

        // Convert food ingredients to lowercase for case-insensitive comparison
        String foodIngredients = food.getIngredients().toLowerCase();

        // Check if any selected ingredient term is present in the food's ingredients
        for (String selectedIngredient : selectedIngredients) {
            String lowerCaseSelectedIngredient = selectedIngredient.toLowerCase();
            if (foodIngredients.contains(lowerCaseSelectedIngredient)) {
                return true; // Return true if at least one selected ingredient matches
            }
        }

        return false;
    }

    private void setVariable() {
        // Any additional variable setup can be done here
    }

    private void updateRecyclerView(ArrayList<Foods> list) {
        if (list.size() > 0) {
            // Show the RecyclerView and hide the "No Result Found" message
            binding.foodListView.setVisibility(View.VISIBLE);
            binding.noResultTxt.setVisibility(View.GONE);
            binding.foodListView.setLayoutManager(new GridLayoutManager(ListFoodsActivity.this, 2));
            adapterListFood = new FoodListAdapter(list);
            binding.foodListView.setAdapter(adapterListFood);
        } else {
            // Hide the RecyclerView and show the "No Result Found" message
            binding.foodListView.setVisibility(View.GONE);
            binding.noResultTxt.setVisibility(View.VISIBLE);
        }
        binding.progressBar.setVisibility(View.GONE);
    }

}
